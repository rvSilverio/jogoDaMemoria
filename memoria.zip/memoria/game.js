function scoreBoardGameControl (){
	var score = 0;
	var POINT_GAME = 10;
	var TEXT_score = "score : "

	var TOTAL_CERTO = 10;
	var certos = 0;

	this.updatescore =  function (){
		var scoreDiv = document.getElementById("score");
		scoreDiv.innerHTML =  TEXT_score + score;
	}

	this.incrementscore =  function (){
		certos++;
		score+= POINT_GAME;
		if (certos ==  TOTAL_CERTO){
			alert("Fim de Jogo! Seu score foi " + score);
		}
	}

	this.decrementscore =  function (){
		score-= POINT_GAME;
	}
}

function Card(picture){
	var FOLDER_IMAGES = 'resources/'
	var IMAGEM_DUVIDA  = "duvida.png"
	this.picture = picture;
	this.visible = false;
	this.block = false;

	this.equals =  function (cardGame){
		if (this.picture.valueOf() == cardGame.picture.valueOf()){
			return true;
		}
		return false;
	}
	this.getPathCardImage =  function(){
		return FOLDER_IMAGES+picture;
	}
	this.getQuestionImage =  function(){
		return FOLDER_IMAGES+IMAGEM_DUVIDA;
	}
}

function ControllerLogicGame(){
	var primeiraSelecao;
	var segundaSelecao;
	var block = false;
	var TIME_SLEEP_BETWEEN_INTERVAL = 1000;
	var eventController = this;

	this.addEventListener =  function (eventName, callback){
		eventController[eventName] = callback;
	};

	this.doLogicGame =  function (card,callback){
		if (!card.block && !block) {
			if (primeiraSelecao == null){
				primeiraSelecao = card;
				card.visible = true;
			}else if (segundaSelecao == null && primeiraSelecao != card){
				segundaSelecao = card;
				card.visible = true;
			}

			if (primeiraSelecao != null && segundaSelecao != null){
				block = true;
				var timer = setInterval(function(){
					if (segundaSelecao.equals(primeiraSelecao)){
						primeiraSelecao.block = true;
						segundaSelecao.block = true;
						eventController["correct"](); 
					}else{
						primeiraSelecao.visible  = false;
						segundaSelecao.visible  = false;
						eventController["wrong"]();
					}        				  		
					primeiraSelecao = null;
					segundaSelecao = null;
					clearInterval(timer);
					block = false;
					eventController["show"]();
				},TIME_SLEEP_BETWEEN_INTERVAL);
			} 
			eventController["show"]();
		};
	};

}

function CardGame (cards , controllerLogicGame,scoreBoard){
	var LINES = 4;
	var COLS  = 5;
	this.cards = cards;
	var logicGame = controllerLogicGame;
	var scoreBoardGameControl = scoreBoard;

	this.clear = function (){
		var game = document.getElementById("game");
		game.innerHTML = '';
	}

	this.show =  function (){
		this.clear();
		scoreBoardGameControl.updatescore();
		var cardCount = 0;
		var game = document.getElementById("game");
		for(var i = 0 ; i < LINES; i++){
			for(var j = 0 ; j < COLS; j++){
				card = cards[cardCount++];
				var cardImage = document.createElement("img");
				if (card.visible){
					cardImage.setAttribute("src",card.getPathCardImage());
				}else{
					cardImage.setAttribute("src",card.getQuestionImage());
				}
				cardImage.onclick =  (function(position,cardGame) {
					return function() {
						card = cards[position];
						var callback =  function (){
							cardGame.show();
						};
						logicGame.addEventListener("correct",function (){
							scoreBoardGameControl.incrementscore();
							scoreBoardGameControl.updatescore();
						});
						logicGame.addEventListener("wrong",function (){
							scoreBoardGameControl.decrementscore();
							scoreBoardGameControl.updatescore();
						});

						logicGame.addEventListener("show",function (){
							cardGame.show();
						});

						logicGame.doLogicGame(card);
						
					};
				})(cardCount-1,this);

				game.appendChild(cardImage);
			}
			var br = document.createElement("br");
			game.appendChild(br);
		}
	}
}

function BuilderCardGame(){
	var pictures = new Array ('10.png','10.png',
		'1.png','1.png',
		'2.png','2.png',
		'3.png','3.png',
		'4.png','4.png',
		'5.png','5.png',
		'6.png','6.png',
		'7.png','7.png',
		'8.png','8.png',
		'9.png','9.png');

	this.doCardGame =  function (){
		shufflePictures();
		cards  = buildCardGame();
		cardGame =  new CardGame(cards, new ControllerLogicGame(), new scoreBoardGameControl())
		cardGame.clear();
		return cardGame;
	}

	var shufflePictures = function(){
		var i = pictures.length, j, tempi, tempj;
		if ( i == 0 ) return false;
		while ( --i ) {
			j = Math.floor( Math.random() * ( i + 1 ) );
			tempi = pictures[i];
			tempj = pictures[j];
			pictures[i] = tempj;
			pictures[j] = tempi;
		}
	}

	var buildCardGame =  function (){
		var countCards = 0;
		cards =  new Array();
		for (var i = pictures.length - 1; i >= 0; i--) {
			card =  new Card(pictures[i]);
			cards[countCards++] = card;
		};
		return cards;
	}
}

function GameControl (){

}

GameControl.createGame = function(){
	var builderCardGame =  new BuilderCardGame();
	cardGame = builderCardGame.doCardGame();
	cardGame.show();
}